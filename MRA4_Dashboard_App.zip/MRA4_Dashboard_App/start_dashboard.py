#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Start-Skript für MRA4 Dashboard
Prüft Abhängigkeiten und startet die Anwendung
"""

import subprocess
import sys
import os

def check_dependencies():
    """Prüft und installiert fehlende Abhängigkeiten"""
    try:
        import pkg_resources

        # requirements.txt lesen
        with open('requirements.txt', 'r') as f:
            requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

        # Fehlende Pakete finden
        missing = []
        for req in requirements:
            try:
                pkg_resources.require(req)
            except:
                missing.append(req)

        # Fehlende Pakete installieren
        if missing:
            print(f"Installiere fehlende Abhängigkeiten: {', '.join(missing)}")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install'] + missing)
            print("Abhängigkeiten installiert!\n")

    except Exception as e:
        print(f"Warnung: Abhängigkeiten konnten nicht automatisch installiert werden: {e}")
        print("Bitte führen Sie manuell aus: pip install -r requirements.txt\n")

if __name__ == '__main__':
    print("="*60)
    print("MRA4 Dashboard wird gestartet...")
    print("="*60)
    print()

    # Abhängigkeiten prüfen
    check_dependencies()

    # Anwendung starten
    print("Dashboard startet...")
    print("Browser öffnet automatisch auf http://127.0.0.1:8050")
    print()
    print("Zum Beenden: Drücken Sie Strg+C")
    print()

    try:
        # app.py ausführen
        subprocess.call([sys.executable, 'app.py'])
    except KeyboardInterrupt:
        print("\nDashboard wurde beendet.")
